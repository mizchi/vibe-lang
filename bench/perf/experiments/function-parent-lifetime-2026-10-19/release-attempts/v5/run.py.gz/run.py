import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path.cwd();out=root/'_build/function-worker-parent-lifetime-3483-20261018-dff3/typed-module-preparation/release-check-current-v5'
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()
paths=git('diff','--cached','--name-only').splitlines();tree=git('write-tree');assert tree=='2f2867fc1b1f403e5427731bd7885be88509f3a4';assert not git('diff','--name-only')
before={p:sha(root/p) for p in paths};env={k:v for k,v in os.environ.items() if not k.startswith('VIBE_')}
report={'complete':False,'command':['pkf','run','release-check'],'head':git('rev-parse','HEAD'),'staged_tree_before':tree,'owned_file_sha256_before':before,'removed_inherited_vibe_settings':True,'scope':'Normal required full release-check on frozen staged submission. Compiled library source differs from the measured snapshot only by separately recorded EOF cleanup; additional changes repair source-gate traversal, mutation targeting, task inputs and new-report audience registration; performance evidence retains original identities. No concurrent source/index edits, builds or tests.'}
def write():
 p=out/'result.json.tmp';p.write_text(json.dumps(report,indent=2)+'\n');p.replace(out/'result.json')
write();started=time.monotonic()
with (out/'run.log').open('w') as log:
 child=subprocess.Popen(report['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 report['live_step']={'pid':child.pid,'start_ticks':pathlib.Path(f'/proc/{child.pid}/stat').read_text().split()[21]};write();code=child.wait()
report.pop('live_step');report.update(exit=code,elapsed_s=time.monotonic()-started,log_sha256=sha(out/'run.log'),staged_tree_after=git('write-tree'),owned_files_unchanged=all(sha(root/p)==h for p,h in before.items()),unstaged_diff=git('diff','--name-only'),status_after=git('status','--porcelain'))
report['complete']=code==0 and report['staged_tree_after']==tree and report['owned_files_unchanged'] and not report['unstaged_diff'];write();print(json.dumps({k:v for k,v in report.items() if k in ['complete','exit','elapsed_s','staged_tree_before','staged_tree_after','owned_files_unchanged','unstaged_diff','log_sha256']},indent=2),flush=True)
raise SystemExit(0 if report['complete'] else (code or 1))
