#!/usr/bin/env python3
import os, sys, json, subprocess, shutil, hashlib
from pathlib import Path
code = subprocess.call([os.environ['SELFBUILD_NATIVE_RUNNER'], *sys.argv[1:]])
if code == 0 and os.environ.get('VIBE_LOWERING_WORKERS'):
    path = Path(os.environ['VIBE_LOWERING_WORKERS'])
    plan = json.loads(path.read_text())
    target = Path(os.environ['SELFBUILD_CAPTURE']) / path.stem
    target.mkdir(parents=True)
    shutil.copy2(plan['context'], target / 'shared.context')
    queues = []
    for queue in plan['queues']:
        rows = []
        for name in queue:
            job = Path(name)
            product = Path(name + '.product')
            shutil.copy2(job, target / job.name)
            rows.append({'name': job.name, 'input_bytes': job.stat().st_size,
                         'product_bytes': product.stat().st_size,
                         'product_sha256': hashlib.sha256(product.read_bytes()).hexdigest()})
        queues.append(rows)
    (target / 'capture.json').write_text(json.dumps({'queues': queues,
        'context_bytes': (target / 'shared.context').stat().st_size}, indent=2) + '\n')
sys.exit(code)
