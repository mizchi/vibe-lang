from pathlib import Path
import json,hashlib,subprocess,sys,shutil
root=Path.cwd();w=root/'_build/function-worker-parent-lifetime-3483-20261018-dff3/typed-module-preparation';out=w/'direct-finish-flags-v1/public';out.mkdir(exist_ok=False);sys.path.insert(0,str(root/'bench/perf'));import selfbuild_baseline as base
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior=json.loads((out.parent/'result.json').read_text());assert prior['complete'];compiler=root/'_build/selfhost/generations/merged-trait-source-2026-10-13_8bed6e9e6/stage2.wasm';assert sha(compiler)==prior['compiler_sha256'];shutil.copyfile(compiler,out.parent/'compiler-before-flags.wasm');r={'complete':False,'scope':'Current phase/library source after direct-flags repair compiled as program by retained prior producer b199; actual public jobs1/2/4 and failure regressions. No new fixpoint or performance claim. Full normal release-check separately rebuilds compiler.','source_sha256':prior['source_sha256'],'compiler_sha256':sha(compiler),'steps':[]}
def write():p=out/'result.json.tmp';p.write_text(json.dumps(r,indent=2)+'\n');p.replace(out/'result.json')
write()
for name,cmd in [('images',['bash','scripts/build_taskgroup_functions.sh',compiler,out/'images']),('public-tests',['python3','scripts/test_taskgroup_functions.py',compiler,out/'images'])]:
 assert all(sha(root/p)==h for p,h in r['source_sha256'].items())
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.Popen([str(x) for x in cmd],cwd=root,env=base.clean_env(root),stdout=f,stderr=subprocess.STDOUT);r['live_step']={'name':name,'pid':p.pid,'start_ticks':Path(f'/proc/{p.pid}/stat').read_text().split()[21]};write();code=p.wait()
 r.pop('live_step');r['steps'].append({'name':name,'exit':code,'log_sha256':sha(out/(name+'.log'))});write();print(name,code,flush=True)
 if code:print((out/(name+'.log')).read_text()[-6000:],flush=True);raise SystemExit(code)
r['image_receipt']=json.loads((out/'images/build.json').read_text())
for name,h in r['image_receipt']['artifacts'].items():assert sha(out/'images'/name)==h
assert all(sha(root/p)==h for p,h in r['source_sha256'].items());r.update(complete=True,source_unchanged=True);write();print('Direct-flags current source public phase regressions pass',flush=True)
