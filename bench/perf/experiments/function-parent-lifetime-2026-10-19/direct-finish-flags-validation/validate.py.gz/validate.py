from pathlib import Path
import hashlib,json,subprocess,sys,shutil
root=Path.cwd();work=root/'_build/function-worker-parent-lifetime-3483-20261018-dff3/typed-module-preparation';out=work/'direct-finish-flags-v1';sys.path.insert(0,str(root/'bench/perf'));import selfbuild_baseline as base
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before=json.loads((out/'before.json').read_text());sources={r['path']:sha(root/r['path']) for r in before};compiler=root/'_build/selfhost/generations/merged-trait-source-2026-10-13_8bed6e9e6/stage2.wasm';runner=root/'runtime/viberun/target/release/viberun';assert sha(compiler)=='b199e63033bb7d9030c8a80e15caef254cbff07951c8642d55f91ba63ef520d0';shutil.copyfile(root/'_build/compile_only/vibe_compile_only.names.wasm',out/'before.names.wasm')
r={'complete':False,'scope':'Direct finishing flags preserve ordinary compile-only constant-Bool specialization; no new performance evidence. Old producer b199 executes current source as the program under test. Rebuilt producer/fixpoint and full required signoff remain separate.','source_sha256':sources,'compiler_sha256':sha(compiler),'runner_sha256':sha(runner),'steps':[]}
def write():p=out/'result.json.tmp';p.write_text(json.dumps(r,indent=2)+'\n');p.replace(out/'result.json')
def run(name,cmd,env=None,stdin=None,expect=0):
 assert all(sha(root/p)==h for p,h in sources.items())
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen([str(s) for s in cmd],env=base.clean_env(root)|(env or {}),cwd=root,stdin=subprocess.PIPE if stdin is not None else None,stdout=log,stderr=subprocess.STDOUT,text=True);r['live_step']={'name':name,'pid':p.pid,'start_ticks':Path(f'/proc/{p.pid}/stat').read_text().split()[21]};write();p.communicate(stdin)
 r.pop('live_step');r['steps'].append({'name':name,'exit':p.returncode,'expected':expect,'log_sha256':sha(out/(name+'.log'))});write();print(name,p.returncode,flush=True)
 if p.returncode!=expect:print((out/(name+'.log')).read_text()[-6000:],flush=True);raise SystemExit(p.returncode or 1)
write();run('format',['bash','scripts/run_vibe_fmt_batch.sh','check','1'],stdin='\n'.join(sources)+'\n');lines=[s for s in (out/'format.log').read_text().splitlines() if s.startswith(('OK\t','DIFF\t','ERROR\t','REFUSED\t'))];assert len(lines)==5 and all(s.startswith('OK\t') for s in lines),lines
run('before-red',['bash','scripts/check_compile_only_lanes.sh','--scan-only',out/'before.names.wasm'],expect=1)
for mode in ['0','1','shadow']:
 module=out/(mode+'.wasm');run('compile-'+mode,[runner,compiler,root/'lib/@vibe/compiler/tests/linked_module_preparation_test.vibe',module,'__no_entry__'],{'VIBE_FS_COMPILE':'1','VIBE_RC':mode,'VIBE_BUILD_CACHE_DIR':str(out/('cache-'+mode))});assert module.exists();d=module.with_suffix('.wasm.diag');assert not d.exists() or not d.stat().st_size
 run('native-'+mode,[runner,module]);run('node-'+mode,['bash','scripts/run_wasm_vibe_host_runner.sh',module])
artifact=out/'after.names.wasm';run('build',['bash','scripts/build_compile_only.sh','--compiler',compiler,'--names','--out',artifact]);r['artifact_sha256']=sha(artifact);write();run('after-green',['bash','scripts/check_compile_only_lanes.sh','--artifact',artifact,'--entry','cli_main_compile_only']);assert all(sha(root/p)==h for p,h in sources.items());r.update(complete=True,source_unchanged=True);write();print('Direct flags ownership/diagnostics6executions and real compile-only lane absence/refusal/acceptance pass',flush=True)
