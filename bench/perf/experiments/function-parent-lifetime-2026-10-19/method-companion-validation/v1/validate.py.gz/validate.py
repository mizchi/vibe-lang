from pathlib import Path
import hashlib,json,subprocess,os,sys,time
root=Path.cwd();work=root/'_build/function-worker-parent-lifetime-3483-20261018-dff3/typed-module-preparation';out=work/'method-companions-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(root/'bench/perf'));import selfbuild_baseline as base
old=json.loads((work/'release-check-current-v5/result.json').read_text());assert old['exit']==1 and old['owned_files_unchanged']
delta=json.loads((out/'source-delta.json').read_text());sources={p:sha(root/p) for p in old['owned_file_sha256_before']};assert all(sources[p]==h for p,h in old['owned_file_sha256_before'].items() if p.startswith(('lib/@vibe/compiler/','runtime/')))
for row in delta['changes']:assert sources[row['path']]==row['after_sha256']
compiler=root/'_build/selfhost/generations/merged-trait-source-2026-10-13_8bed6e9e6/stage2.wasm';runner=root/'runtime/viberun/target/release/viberun';assert sha(compiler)=='b199e63033bb7d9030c8a80e15caef254cbff07951c8642d55f91ba63ef520d0';assert sha(runner)=='3a936e6c4947a7896051890c08d904c5a5c1106c67b5940bcad7260c770469e7'
report={'complete':False,'scope':'Post-measurement additive qualified method companions only, original function bodies/compiled compiler/native unchanged. Actual qualified calls execute existing ownership/transport/replay negative regressions and matching rebuilt public phases. No retiming/new performance claim.','source_sha256':sources,'source_delta':delta,'compiler_sha256':sha(compiler),'runner_sha256':sha(runner),'steps':[]}
def write():p=out/'result.json.tmp';p.write_text(json.dumps(report,indent=2)+'\n');p.replace(out/'result.json')
def verify():assert all(sha(root/p)==h for p,h in sources.items()),'Owned sources changed during validation'
def run(name,cmd,env=None,stdin=None):
 verify();start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen([str(a) for a in cmd],cwd=root,env=base.clean_env(root)|(env or {}),stdin=subprocess.PIPE if stdin is not None else None,stdout=log,stderr=subprocess.STDOUT,text=True);report['live_step']={'name':name,'pid':p.pid,'start_ticks':Path(f'/proc/{p.pid}/stat').read_text().split()[21]};write();p.communicate(stdin);code=p.returncode
 report.pop('live_step');report['steps'].append({'name':name,'exit':code,'log_sha256':sha(out/(name+'.log')),'elapsed_s_diagnostic_only':time.monotonic()-start});write();verify();print(name,code,flush=True)
 if code:print((out/(name+'.log')).read_text()[-7000:],flush=True);raise SystemExit(code)
write();run('naming',['bash','scripts/lint_method_style_naming.sh']);run('format',['bash','scripts/run_vibe_fmt_batch.sh','check','1'],stdin=(out/'format-files.txt').read_text());lines=[s for s in (out/'format.log').read_text().splitlines() if s.startswith(('OK\t','DIFF\t','ERROR\t','REFUSED\t'))];assert len(lines)==7 and all(s.startswith('OK\t') for s in lines),lines
run('native-authority',['bash','scripts/ensure_viberun.sh','--check'])
for fixture in ['qualified_context_test.vibe','qualified_assembly_test.vibe','qualified_receipt.vibe']:
 for mode in ['0','1','shadow']:
  label=fixture+'-'+mode;module=out/(label+'.wasm');entry='main' if fixture=='qualified_receipt.vibe' else '__no_entry__'
  run('compile-'+label,[runner,compiler,out/fixture,module,entry],{'VIBE_FS_COMPILE':'1','VIBE_RC':mode,'VIBE_BUILD_CACHE_DIR':str(out/(label+'-cache')),'VIBE_NATIVE_CACHE_DIR':str(out/'native-cache')});assert module.is_file() and module.stat().st_size>0;diag=module.with_suffix('.wasm.diag');assert not diag.exists() or not diag.stat().st_size
  run('native-'+label,[runner,module]);run('node-'+label,['bash','scripts/run_wasm_vibe_host_runner.sh',module])
run('images',['bash','scripts/build_taskgroup_functions.sh',compiler,out/'images']);receipt=json.loads((out/'images/build.json').read_text());assert receipt['compiler_sha256']==sha(compiler) and receipt['runner_sha256']==sha(runner)
for name,h in receipt['artifacts'].items():assert sha(out/'images'/name)==h
report['image_receipt']=receipt;write();run('public-tests',['python3','scripts/test_taskgroup_functions.py',compiler,out/'images']);verify();report.update(complete=True,source_unchanged=True);write();print('8qualified methods,18host/mode executions and rebuilt public phase suite pass',flush=True)
